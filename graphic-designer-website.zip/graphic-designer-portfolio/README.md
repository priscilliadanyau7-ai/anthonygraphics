# Graphic Designer Portfolio

A responsive graphic designer landing page with an Express backend.

## Features
- Responsive portfolio landing page
- Work, services, about and contact sections
- WhatsApp contact button already connected to **08083720669**
- Contact form posts to `POST /api/inquiries`
- Backend saves inquiries in `data/inquiries.json`

## Run locally
1. Install Node.js 18 or newer.
2. Extract this ZIP and open a terminal in the project folder.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3000`.

## Customize before publishing
- Open `public/index.html` and replace `STUDIO` with your designer/brand name.
- Replace the sample project cards with your real portfolio images and descriptions.
- Edit the services and About text to match your work.
- The WhatsApp link is currently set to `https://wa.me/2348083720669`.

## Backend notes
Submitted inquiries are stored in `data/inquiries.json` on the server. This starter is suitable for a small deployment or prototype. For production, use a persistent database and add spam protection, HTTPS, backups and access controls. Do not expose `data/inquiries.json` as a public static file.
