const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");
const INQUIRIES_FILE = path.join(DATA_DIR, "inquiries.json");

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(INQUIRIES_FILE)) fs.writeFileSync(INQUIRIES_FILE, "[]", "utf8");

app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/inquiries", (req, res) => {
  const { name, email, service, message } = req.body || {};
  if (![name, email, service, message].every(v => typeof v === "string" && v.trim())) {
    return res.status(400).json({ error: "Please complete every field." });
  }
  if (name.length > 100 || email.length > 160 || service.length > 100 || message.length > 3000) {
    return res.status(400).json({ error: "One or more fields are too long." });
  }
  const inquiry = {
    id: Date.now().toString(),
    name: name.trim(),
    email: email.trim(),
    service: service.trim(),
    message: message.trim(),
    receivedAt: new Date().toISOString()
  };
  try {
    const records = JSON.parse(fs.readFileSync(INQUIRIES_FILE, "utf8"));
    records.push(inquiry);
    fs.writeFileSync(INQUIRIES_FILE, JSON.stringify(records, null, 2), "utf8");
    res.status(201).json({ success: true, message: "Thanks! Your inquiry has been received." });
  } catch (err) {
    console.error("Could not save inquiry:", err);
    res.status(500).json({ error: "Unable to save your message right now." });
  }
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`Portfolio running at http://localhost:${PORT}`));